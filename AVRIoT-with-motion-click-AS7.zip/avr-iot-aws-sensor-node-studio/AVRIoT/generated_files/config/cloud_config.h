#ifndef CLOUD_CONFIG_H
#define CLOUD_CONFIG_H

//Thing Name configuration

//Use this thing Name in the event of not reading it from WINC
#define AWS_THING_NAME        ""  


// </h>
#endif // CLOUD_CONFIG_H
